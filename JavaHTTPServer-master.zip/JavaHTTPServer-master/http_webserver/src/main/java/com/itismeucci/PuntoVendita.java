package com.itismeucci;

import java.util.ArrayList;

public class PuntoVendita {
    
    private int size;
    private ArrayList<Risultato> listaRisultati;

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public ArrayList<Risultato> getListaRisultati() {
        return listaRisultati;
    }

    public void setListaRisultati(ArrayList<Risultato> listaRisultati) {
        this.listaRisultati = listaRisultati;
    }

}
