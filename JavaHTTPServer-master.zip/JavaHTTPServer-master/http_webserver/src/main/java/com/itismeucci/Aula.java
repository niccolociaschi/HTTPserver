package com.itismeucci;

public class Aula {

    private String nome;
    private int numeroDiBanchi;

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNumeroDiBanchi() {
        return this.numeroDiBanchi;
    }

    public void setNumeroDiBanchi(int numeroDiBanchi) {
        this.numeroDiBanchi = numeroDiBanchi;
    }

}